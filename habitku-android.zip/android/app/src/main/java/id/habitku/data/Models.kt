package id.habitku.data

data class Habit(
    val id: String,
    val name: String,
    val category: Int,      // index into CATEGORY_NAMES
    val createdOn: String,  // ISO date
)

data class Session(
    val id: String,
    val activity: String,
    val startedAt: Long,
    val distanceM: Float,
    val durationS: Long,
)

data class AppData(
    val name: String = "Friend",
    val habits: List<Habit> = emptyList(),
    val logs: Map<String, Set<String>> = emptyMap(),   // habitId -> completed ISO dates
    val sessions: List<Session> = emptyList(),
)

val CATEGORY_NAMES = listOf("Health & Fitness", "Productivity", "Finance", "Mental Wellbeing")
