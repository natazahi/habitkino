package id.habitku.data

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import java.time.LocalDate
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var data by mutableStateOf(store.load())
        private set

    private fun update(f: (AppData) -> AppData) {
        data = f(data)
        store.save(data)
    }

    fun addHabit(name: String, category: Int) = update { d ->
        val h = Habit(UUID.randomUUID().toString(), name.trim().take(60), category, LocalDate.now().toString())
        d.copy(habits = d.habits + h)
    }

    fun deleteHabit(id: String) = update { d ->
        d.copy(habits = d.habits.filterNot { it.id == id }, logs = d.logs - id)
    }

    fun toggle(id: String, date: String) = update { d ->
        val cur = d.logs[id] ?: emptySet()
        val next = if (date in cur) cur - date else cur + date
        d.copy(logs = d.logs + (id to next))
    }

    fun addSession(s: Session) = update { d -> d.copy(sessions = listOf(s) + d.sessions) }

    fun setName(n: String) = update { d ->
        d.copy(name = n.trim().take(40).ifEmpty { "Friend" })
    }

    fun resetAll() = update { AppData() }
}
