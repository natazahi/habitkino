package id.habitku.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Indigo = Color(0xFF4F46E5)
val Green = Color(0xFF10B981)
val Amber = Color(0xFFF59E0B)
val CategoryColors = listOf(
    Color(0xFFEF4444), // Health & Fitness
    Color(0xFF3B82F6), // Productivity
    Color(0xFF10B981), // Finance
    Color(0xFFA855F7), // Mental
)

private val LightScheme = lightColorScheme(
    primary = Indigo,
    background = Color(0xFFF6F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFE8EAF2),
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF818CF8),
    background = Color(0xFF0E0E13),
    surface = Color(0xFF16161D),
    surfaceVariant = Color(0xFF2A2A35),
)

@Composable
fun HabitKuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme,
        content = content,
    )
}
