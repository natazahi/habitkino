package id.habitku.track

import android.location.Location
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class TrackPoint(val lat: Double, val lng: Double, val timeMs: Long)

data class TrackState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val kind: String = "walk",
    val startedAtMs: Long = 0L,
    val points: List<TrackPoint> = emptyList(),
    val distanceM: Float = 0f,
    val speedMps: Float = 0f,
    val accumulatedMs: Long = 0L,
    val resumedAtMs: Long? = null,
) {
    fun elapsedS(now: Long): Long = (accumulatedMs + (resumedAtMs?.let { now - it } ?: 0L)) / 1000
}

/** Single source of truth for live tracking. Only TrackService writes points; screens only read. */
object TrackRepo {
    private const val MAX_ACCURACY_M = 50f
    private val _state = MutableStateFlow(TrackState())
    val state: StateFlow<TrackState> = _state.asStateFlow()

    fun start(kind: String) {
        val now = System.currentTimeMillis()
        _state.value = TrackState(running = true, kind = kind, startedAtMs = now, resumedAtMs = now)
    }

    fun pause() = _state.update {
        if (!it.running || it.paused) it
        else it.copy(
            paused = true,
            accumulatedMs = it.accumulatedMs + (System.currentTimeMillis() - (it.resumedAtMs ?: System.currentTimeMillis())),
            resumedAtMs = null,
            speedMps = 0f,
        )
    }

    fun resume() = _state.update {
        if (it.paused) it.copy(paused = false, resumedAtMs = System.currentTimeMillis()) else it
    }

    fun finish(): TrackState {
        pause()
        val last = _state.value
        _state.value = TrackState()
        return last
    }

    fun onLocation(loc: Location) = _state.update { s ->
        if (!s.running || s.paused || loc.accuracy > MAX_ACCURACY_M) return@update s
        val prev = s.points.lastOrNull()
        val added = if (prev == null) 0f else {
            val out = FloatArray(1)
            Location.distanceBetween(prev.lat, prev.lng, loc.latitude, loc.longitude, out)
            out[0]
        }
        s.copy(
            points = s.points + TrackPoint(loc.latitude, loc.longitude, System.currentTimeMillis()),
            distanceM = s.distanceM + added,
            speedMps = if (loc.hasSpeed()) loc.speed else s.speedMps,
        )
    }
}
