package id.habitku.ui.act

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import id.habitku.data.AppViewModel
import id.habitku.data.Session
import id.habitku.data.fmtDuration
import id.habitku.data.fmtKm
import id.habitku.track.TrackRepo
import id.habitku.track.TrackService
import kotlinx.coroutines.delay
import java.util.UUID

@Composable
fun ActivityScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val s by TrackRepo.state.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var kind by remember { mutableStateOf("walk") }
    var summary by remember { mutableStateOf<Session?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    fun begin() {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            message = "Turn on Location (GPS) in your phone settings, then try again."
            return
        }
        message = null
        TrackRepo.start(kind)
        ContextCompat.startForegroundService(ctx, Intent(ctx, TrackService::class.java))
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) begin()
        else message = "Location permission is needed to track your route."
    }

    fun requestStart() {
        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (fine) {
            begin()
        } else {
            val perms = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            launcher.launch(perms.toTypedArray())
        }
    }

    val elapsed = s.elapsedS(now)

    Box(Modifier.fillMaxSize()) {
        TrackMap(points = s.points, modifier = Modifier.fillMaxSize())

        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(16.dp),
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat("Distance", fmtKm(s.distanceM))
                    Stat("Time", fmtDuration(elapsed))
                    Stat("Speed", "%.1f km/h".format(s.speedMps * 3.6f))
                }

                if (!s.running) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("walk", "run", "cycle").forEach { k ->
                            FilterChip(
                                selected = kind == k,
                                onClick = { kind = k },
                                label = { Text(k.replaceFirstChar { it.uppercase() }) },
                            )
                        }
                    }
                    Button(
                        onClick = { requestStart() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                    ) { Text("Start") }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { if (s.paused) TrackRepo.resume() else TrackRepo.pause() },
                            modifier = Modifier.weight(1f).height(56.dp),
                        ) { Text(if (s.paused) "Resume" else "Pause") }
                        Button(
                            onClick = {
                                ctx.stopService(Intent(ctx, TrackService::class.java))
                                val r = TrackRepo.finish()
                                summary = Session(
                                    id = UUID.randomUUID().toString(),
                                    activity = r.kind,
                                    startedAt = r.startedAtMs,
                                    distanceM = r.distanceM,
                                    durationS = r.elapsedS(0L),
                                )
                            },
                            modifier = Modifier.weight(1f).height(56.dp),
                        ) { Text("Finish") }
                    }
                    if (s.points.isEmpty()) {
                        Text(
                            "Waiting for GPS signal. Go outdoors for the best accuracy.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }

                message?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    summary?.let { r ->
        AlertDialog(
            onDismissRequest = { summary = null },
            title = { Text("Activity finished") },
            text = { Text("${fmtKm(r.distanceM)} in ${fmtDuration(r.durationS)}") },
            confirmButton = {
                TextButton(onClick = { vm.addSession(r); summary = null }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { summary = null }) { Text("Discard") }
            },
        )
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}
