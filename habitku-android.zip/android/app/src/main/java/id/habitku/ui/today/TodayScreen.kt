package id.habitku.ui.today

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import id.habitku.data.*
import id.habitku.ui.comp.HabitCard
import id.habitku.ui.comp.ProgressRing
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun TodayScreen(vm: AppViewModel) {
    val d = vm.data
    val today = LocalDate.now()
    val todayKey = today.toString()
    val done = d.habits.count { todayKey in (d.logs[it.id] ?: emptySet()) }
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Habit?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, top = 20.dp, end = 20.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("Hi, ${d.name}", style = MaterialTheme.typography.headlineMedium)
                Text(
                    today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ProgressRing(
                        progress = if (d.habits.isEmpty()) 0f else done / d.habits.size.toFloat(),
                        centerText = "$done/${d.habits.size}",
                    )
                    Column {
                        Text("Today's progress", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (d.habits.isEmpty()) "Add your first habit to begin"
                            else if (done == d.habits.size) "All done. Great work!"
                            else "${d.habits.size - done} left to go",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
            items(d.habits, key = { it.id }) { h ->
                val logs = d.logs[h.id] ?: emptySet()
                HabitCard(
                    habit = h,
                    streak = currentStreak(logs, today),
                    done = todayKey in logs,
                    onToggle = { vm.toggle(h.id, todayKey) },
                    onDelete = { toDelete = h },
                )
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            icon = { Icon(Icons.Default.Add, contentDescription = null) },
            text = { Text("New habit") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        )
    }

    if (showAdd) {
        AddHabitDialog(
            onDismiss = { showAdd = false },
            onAdd = { name, cat -> vm.addHabit(name, cat); showAdd = false },
        )
    }

    toDelete?.let { h ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete habit?") },
            text = { Text("\"${h.name}\" and its history will be removed from this device.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteHabit(h.id); toDelete = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun AddHabitDialog(onDismiss: () -> Unit, onAdd: (String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var cat by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New habit") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 60) name = it },
                    label = { Text("Name") },
                    singleLine = true,
                )
                Spacer(Modifier.height(12.dp))
                CATEGORY_NAMES.forEachIndexed { i, c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { cat = i },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = cat == i, onClick = { cat = i })
                        Text(c)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onAdd(name, cat) }, enabled = name.isNotBlank()) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
