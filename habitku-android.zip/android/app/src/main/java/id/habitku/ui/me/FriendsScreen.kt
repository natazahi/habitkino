package id.habitku.ui.me

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import id.habitku.ui.comp.AppCard

@Composable
fun FriendsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Friends", style = MaterialTheme.typography.headlineMedium)
        AppCard {
            Text("Coming with the online backend", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "Friend requests, the leaderboard and location sharing need an account on a server. " +
                    "This build stores everything on your phone, so these features are switched off for now.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}
