package id.habitku.ui.me

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import id.habitku.data.*
import id.habitku.ui.comp.AppCard

@Composable
fun ProfileScreen(vm: AppViewModel) {
    val d = vm.data
    var name by remember(d.name) { mutableStateOf(d.name) }
    var confirmReset by remember { mutableStateOf(false) }
    val pts = totalPoints(d)

    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { Text("Profile", style = MaterialTheme.typography.headlineMedium) }

        item {
            AppCard {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text("Display name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.setName(name) }) { Text("Save name") }
                Spacer(Modifier.height(8.dp))
                Text("Level ${levelOf(pts)} \u00B7 $pts points", style = MaterialTheme.typography.bodyMedium)
            }
        }

        item { Text("Badges", style = MaterialTheme.typography.titleMedium) }
        items(badgesOf(d)) { b ->
            AppCard {
                Text(
                    (if (b.earned) "\u2705 " else "\uD83D\uDD12 ") + b.name,
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(b.description, style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            AppCard {
                Text("Your data", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Everything is stored only on this phone. Location is used only while you run a tracked activity.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { confirmReset = true }) { Text("Delete all my data") }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Delete everything?") },
            text = { Text("All habits, history and activities on this device will be erased. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { vm.resetAll(); confirmReset = false }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } },
        )
    }
}
