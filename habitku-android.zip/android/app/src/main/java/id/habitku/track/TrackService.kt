package id.habitku.track

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder

/** Foreground service that feeds GPS fixes into TrackRepo while an activity is running. */
class TrackService : Service(), LocationListener {
    private lateinit var lm: LocationManager

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("track", "Activity tracking", NotificationManager.IMPORTANCE_LOW)
        )
        val notif = Notification.Builder(this, "track")
            .setContentTitle("HabitKu is tracking your activity")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(1, notif)
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 5f, this)
        } catch (e: SecurityException) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onLocationChanged(location: Location) {
        TrackRepo.onLocation(location)
    }

    override fun onDestroy() {
        lm.removeUpdates(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
