package id.habitku.data

import java.time.LocalDate

const val POINTS_PER_CHECKIN = 10
const val POINTS_PER_KM = 10
val LEVEL_THRESHOLDS = listOf(0, 100, 300, 700, 1500, 3000, 6000)

fun currentStreak(done: Set<String>, today: LocalDate): Int {
    var d = if (today.toString() in done) today else today.minusDays(1)
    var n = 0
    while (d.toString() in done) {
        n++
        d = d.minusDays(1)
    }
    return n
}

fun longestStreak(done: Set<String>): Int {
    val days = done.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
    var best = 0
    var run = 0
    var prev: LocalDate? = null
    for (d in days) {
        val p = prev
        run = if (p != null && p.plusDays(1) == d) run + 1 else 1
        if (run > best) best = run
        prev = d
    }
    return best
}

fun rate7(done: Set<String>, today: LocalDate): Int =
    (0..6).count { today.minusDays(it.toLong()).toString() in done } * 100 / 7

fun totalPoints(d: AppData): Int =
    d.logs.values.sumOf { it.size } * POINTS_PER_CHECKIN +
        d.sessions.sumOf { (it.distanceM / 1000f * POINTS_PER_KM).toInt() }

fun levelOf(points: Int): Int = LEVEL_THRESHOLDS.indexOfLast { points >= it } + 1

fun nextThreshold(points: Int): Int? = LEVEL_THRESHOLDS.firstOrNull { it > points }

data class BadgeInfo(val name: String, val description: String, val earned: Boolean)

fun badgesOf(d: AppData): List<BadgeInfo> {
    val total = d.logs.values.sumOf { it.size }
    val best = d.logs.values.maxOfOrNull { longestStreak(it) } ?: 0
    return listOf(
        BadgeInfo("First Step", "Complete your first check-in", total >= 1),
        BadgeInfo("7-Day Streak", "Keep one habit going for 7 days", best >= 7),
        BadgeInfo("30-Day Streak", "Keep one habit going for 30 days", best >= 30),
        BadgeInfo("On the Move", "Finish a tracked activity", d.sessions.isNotEmpty()),
        BadgeInfo("All-Rounder", "Have habits in all 4 categories", d.habits.map { it.category }.toSet().size == 4),
    )
}

fun fmtDuration(s: Long): String = "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
fun fmtKm(m: Float): String = "%.2f km".format(m / 1000f)
