package id.habitku.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Saves everything on the device as one JSON string. Replaced by the API client when the backend is connected. */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("habitku", Context.MODE_PRIVATE)

    fun load(): AppData {
        val raw = prefs.getString("data", null) ?: return AppData()
        return try {
            val o = JSONObject(raw)
            val ha = o.getJSONArray("habits")
            val habits = (0 until ha.length()).map { i ->
                val h = ha.getJSONObject(i)
                Habit(h.getString("id"), h.getString("name"), h.getInt("category"), h.getString("createdOn"))
            }
            val lo = o.getJSONObject("logs")
            val logs = lo.keys().asSequence().associateWith { k ->
                val a = lo.getJSONArray(k)
                (0 until a.length()).map { a.getString(it) }.toSet()
            }
            val sa = o.getJSONArray("sessions")
            val sessions = (0 until sa.length()).map { i ->
                val s = sa.getJSONObject(i)
                Session(
                    s.getString("id"), s.getString("activity"), s.getLong("startedAt"),
                    s.getDouble("distanceM").toFloat(), s.getLong("durationS"),
                )
            }
            AppData(o.optString("name", "Friend"), habits, logs, sessions)
        } catch (e: Exception) {
            AppData()
        }
    }

    fun save(d: AppData) {
        val o = JSONObject()
        o.put("name", d.name)
        val ha = JSONArray()
        d.habits.forEach { h ->
            ha.put(
                JSONObject().put("id", h.id).put("name", h.name)
                    .put("category", h.category).put("createdOn", h.createdOn)
            )
        }
        o.put("habits", ha)
        val lo = JSONObject()
        d.logs.forEach { (k, v) -> lo.put(k, JSONArray(v.toList())) }
        o.put("logs", lo)
        val sa = JSONArray()
        d.sessions.forEach { s ->
            sa.put(
                JSONObject().put("id", s.id).put("activity", s.activity)
                    .put("startedAt", s.startedAt).put("distanceM", s.distanceM.toDouble())
                    .put("durationS", s.durationS)
            )
        }
        o.put("sessions", sa)
        prefs.edit().putString("data", o.toString()).apply()
    }
}
