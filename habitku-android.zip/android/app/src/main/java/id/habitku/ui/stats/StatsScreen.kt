package id.habitku.ui.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import id.habitku.data.*
import id.habitku.ui.comp.AppCard
import id.habitku.ui.theme.Green
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun StatsScreen(vm: AppViewModel) {
    val d = vm.data
    val today = LocalDate.now()
    val pts = totalPoints(d)
    val level = levelOf(pts)
    val next = nextThreshold(pts)
    val floor = LEVEL_THRESHOLDS[level - 1]

    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { Text("Statistics", style = MaterialTheme.typography.headlineMedium) }

        item {
            AppCard {
                Text("Level $level", style = MaterialTheme.typography.titleLarge)
                Text("$pts points", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                if (next != null) {
                    LinearProgressIndicator(
                        progress = { (pts - floor).toFloat() / (next - floor) },
                        modifier = Modifier.fillMaxWidth().height(10.dp),
                    )
                    Text("${next - pts} points to level ${level + 1}", style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("Max level reached", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            AppCard {
                Text("Last 7 days", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                val days = (6 downTo 0).map { today.minusDays(it.toLong()) }
                val counts = days.map { dt -> d.habits.count { dt.toString() in (d.logs[it.id] ?: emptySet()) } }
                val max = maxOf(1, d.habits.size)
                Row(
                    Modifier.fillMaxWidth().height(110.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom,
                ) {
                    days.forEachIndexed { i, dt ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.width(24.dp)
                                    .height((80 * counts[i] / max).coerceAtLeast(4).dp)
                                    .background(
                                        if (counts[i] > 0) Green else MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp),
                                    )
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(dt.format(DateTimeFormatter.ofPattern("EEE")).take(2), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        item { Text("Habits", style = MaterialTheme.typography.titleMedium) }
        if (d.habits.isEmpty()) {
            item { Text("No habits yet. Add one on the Today tab.", style = MaterialTheme.typography.bodyMedium) }
        }
        d.habits.forEach { h ->
            item(key = h.id) {
                val logs = d.logs[h.id] ?: emptySet()
                AppCard {
                    Text(h.name, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Streak: ${currentStreak(logs, today)}", style = MaterialTheme.typography.bodySmall)
                        Text("Best: ${longestStreak(logs)}", style = MaterialTheme.typography.bodySmall)
                        Text("7 days: ${rate7(logs, today)}%", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        item { Text("Recent activities", style = MaterialTheme.typography.titleMedium) }
        if (d.sessions.isEmpty()) {
            item { Text("No tracked activities yet.", style = MaterialTheme.typography.bodyMedium) }
        }
        d.sessions.take(5).forEach { s ->
            item(key = s.id) {
                AppCard {
                    Text(s.activity.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.titleMedium)
                    Text("${fmtKm(s.distanceM)} in ${fmtDuration(s.durationS)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
