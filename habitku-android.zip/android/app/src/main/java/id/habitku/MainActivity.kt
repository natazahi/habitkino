package id.habitku

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import id.habitku.data.AppViewModel
import id.habitku.ui.act.ActivityScreen
import id.habitku.ui.me.FriendsScreen
import id.habitku.ui.me.ProfileScreen
import id.habitku.ui.stats.StatsScreen
import id.habitku.ui.theme.HabitKuTheme
import id.habitku.ui.today.TodayScreen

private data class NavItem(val label: String, val icon: ImageVector)

private val NAV = listOf(
    NavItem("Today", Icons.Default.Home),
    NavItem("Stats", Icons.Default.Star),
    NavItem("Activity", Icons.Default.LocationOn),
    NavItem("Friends", Icons.Default.Face),
    NavItem("Profile", Icons.Default.Person),
)

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { HabitKuTheme { App(vm) } }
    }
}

@Composable
private fun App(vm: AppViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                NAV.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> TodayScreen(vm)
                1 -> StatsScreen(vm)
                2 -> ActivityScreen(vm)
                3 -> FriendsScreen()
                else -> ProfileScreen(vm)
            }
        }
    }
}
