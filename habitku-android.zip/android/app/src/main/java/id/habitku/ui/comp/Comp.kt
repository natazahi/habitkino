package id.habitku.ui.comp

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import id.habitku.data.Habit
import id.habitku.ui.theme.CategoryColors
import id.habitku.ui.theme.Green

@Composable
fun ProgressRing(progress: Float, centerText: String, size: Dp = 120.dp) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val sweep by animateFloatAsState(progress.coerceIn(0f, 1f), label = "ring")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val stroke = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
            drawArc(color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false, style = stroke)
            drawArc(color = Green, startAngle = -90f, sweepAngle = 360f * sweep, useCenter = false, style = stroke)
        }
        Text(centerText, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun HabitCard(
    habit: Habit,
    streak: Int,
    done: Boolean,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
) {
    val checkBg by animateColorAsState(
        if (done) Green else MaterialTheme.colorScheme.surfaceVariant, label = "check"
    )
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier.size(width = 6.dp, height = 40.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(CategoryColors[habit.category.coerceIn(0, 3)])
            )
            Column(Modifier.weight(1f)) {
                Text(habit.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (streak > 0) "🔥 $streak day streak" else "Start your streak today",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(checkBg).clickable(onClick = onToggle),
                contentAlignment = Alignment.Center,
            ) {
                if (done) Icon(Icons.Default.Check, contentDescription = "Done", tint = Color.White)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete habit")
            }
        }
    }
}
