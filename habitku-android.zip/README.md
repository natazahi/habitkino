# HabitKu (Android)

Habit tracker with live activity tracking. Everything is stored on the phone for now.

## Get the APK (no coding)
1. Create a free GitHub account and a new repository.
2. Upload all files from this folder to the repository (keep the `android` folder and the `.github/workflows` folder).
3. Open the repository > Actions tab > "Build APK" > Run workflow (it also runs on every upload to `main`).
4. When it turns green, open the run and download `habitku-debug-apk` under Artifacts. Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone and install it (allow "install unknown apps" for your file manager or browser).

## Build locally
Open the `android` folder in Android Studio and press Run.
